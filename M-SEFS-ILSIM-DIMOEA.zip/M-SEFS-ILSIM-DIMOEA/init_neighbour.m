function neighbour = init_neighbour(weights,T,Popsize)
distance = pdist2(weights,weights);
[~,B] = sort(distance,2);
neighbour = B(:,1:T);
end

