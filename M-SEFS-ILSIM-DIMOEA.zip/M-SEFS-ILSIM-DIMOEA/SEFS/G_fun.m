function [g] =G_fun(a,b)
%The function used to compute the results of the similarity degree. EFSN
%There are three possible cases the function G_fun gives.
if a>0
    g=erf(b)-erf(a);
elseif (b<0)
    g=erf(-a)-erf(-b);
else
    g=erf(-a)+erf(b);
end

end

