function [result,c,sigma,psi,ad_cum,n_0,ad_time,ad_num,P,add_thr,error,rule_num_dy,error_train,error_test,y_est,y_train,y_test,sigmav,CE,n_0_d,y_min,y_max,in_xe] = SEFS_main2(in_x, out_y,test_x, Da, Db, bound_l, bound_u, lambda, sim_degree, Omega,i,c,sigma,psi,ad_cum,n_0,ad_time,ad_num,P,add_thr,error,rule_num_dy,error_train,error_test,y_est,y_train,y_test,sigmav,CE,n_0_d,y_min,y_max,k,s)
    R_num=rows(c);
    mb=exp(-(ones(R_num,1)*in_x(1,:)-c).^2./(2.*sigma.^2));
    ad=prod(mb,2);
    ads=ad./sum(ad);
    in_xe=[ones(1,1),in_x];
 
    w_psix=(psi(:,end- size(ads,1)+1:end)'*in_xe(1,:)').*ads;
    y_test(i)=sum(w_psix);
    error_test(i)=out_y(1)-y_test(i);
    n=1;
    mb=exp(-(ones(R_num,1)*in_x(1,:)-c).^2./(2.*sigma.^2));
    ad=prod(mb,2);%ad is the activation degree of each fuzzy rule
    ads=ad./sum(ad);
    ad_cum=ad_cum(end-size(ad,1)+1:end)+ad;%ad_cum stores the cumulative activation degree of each cluster since it been built.
    %ad_cum is used for pruning redundant fuzzy rules
    [admax,admax_id]=max(ad);%select the most activated cluster
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %Add a new fuzzy rule or update the most activated rule accordding to
     %the activation degree.
    [c,sigma,ad_cum,ad_time,add_indicator,ad_num,P,psi]...
        =add_update_EFSN(in_x(1,:),c,sigma,ads,n_0,n,admax,admax_id,ad_cum,ad_time,i,ad_num,P,psi,Omega,add_thr);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Merge two similar fuzzy rules.
    %Merging happens only if there is no new rule added in this step. (i.e. Merging happens when add_indicator=0.)
   R_num=rows(c);
    if (add_indicator==0)&&(R_num~=1)
        
        [c,sigma,ad_cum,ad_time,ad_num,P,psi,~]=merge_EFSN_L2_revised_final(c,sigma,n,admax_id,ad_cum,ad_time,ad_num,P,psi,R_num,sim_degree,Da,Db);
       
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Computing the model output hat{y_i}
    %Calculate the membership degree
    R_num=rows(c);
    mb=exp(-(ones(R_num,1)*in_x(1,:)-c).^2./(2.*sigma.^2));
    ad=prod(mb,2);
    ads=ad./sum(ad);
    w_psix=(psi(:,end- size(ads,1)+1:end)'*in_xe(1,:)').*ads;
    y_est(i)=sum(w_psix);
    error(i)=abs(out_y(1)-y_est(i));
    rule_num_dy(i)=R_num;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %VFF-WRLS
    c1=8;
    beta=0.9;
    M=10^3;
   [sigmav,P,psi]=VFF_WRLS(n,R_num,ads,error(i),i,in_xe(1,:),c1,M,beta,sigmav,P,psi,out_y(1));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    mb=exp(-(ones(R_num,1)*in_x(1,:)-c).^2./(2.*sigma.^2));
    ad=prod(mb,2);
    ads=ad./sum(ad);
   w_psix=(psi(:,end- size(ads,1)+1:end)'*in_xe(1,:)').*ads;
    y_train(i)=sum(w_psix);
    error_train(i)=abs(out_y(1)-y_train(i));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     CE_p=CE;
    CE=lambda*CE+error_train(i);
%     CE_d=abs(CE-CE_p);
%     CEM(i)=CE;
    add_thr=-(bound_u-bound_l)*exp(-CE)+bound_u;
    n_0=sqrt(-2*log(add_thr)); 
    n_0_dn=[n_0_d;n_0];
    n_0_d=n_0_dn;
    y_min=min(out_y(1),y_min);
    y_max=max(out_y(1),y_max);
    range_y=abs(y_max-y_min);
    result = sum((psi(:,end- size(ads,1)+1:end)'*test_x(1,:)').*ads);
 end