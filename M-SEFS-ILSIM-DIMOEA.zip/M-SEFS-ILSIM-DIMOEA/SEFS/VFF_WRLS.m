function [sigmav,P,psi] = VFF_WRLS(n,R_num,ads,error,i,in_xe0,c1,M,beta,sigmav,P,psi,out_y0)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

ek=zeros(R_num,1);
 tk=zeros(n+1,R_num);
t0=sqrt(c1*sigmav);
efk=zeros(R_num,1);
sigmak=zeros(R_num,1);
sigmav=((i-1)/i)*sigmav+(error)^2/i;
lambdak=zeros(R_num,1);
tauk=zeros(R_num,1);
gk=zeros(n+1,R_num);
muk=1;
%L=zeros(n+1,R_num);
for j=1:R_num
   % ek(j)=out_y0-in_xe0*psi(:,j);%My original version     
    ek(j)=out_y0-in_xe0*psi(:,j);% What E. Lughofer suggested to add the weight to the errors.     
    tk(:,j)=P(:,:,j)*in_xe0';
    efk(j)=sign(ek(j))*max(abs(ek(j))-t0,0);
    sigmak(j)=beta*sigmak(j)+(1-beta)*efk(j)^2;
    lambdak(j)=1-2*sigmak(j)/(M*(sigmak(j)+c1*sigmav));
    tauk(j)=1/(lambdak(j)+in_xe0*tk(:,j)*ads(j));
    gk(:,j)=sqrt(tauk(j))*tk(:,j);   
    %L(:,j)=ads(j)*P(:,:,j)*in_xe0'/(lambdak(j)+in_xe0*P(:,:,j)*in_xe0');
    %P(:,:,j)=lambdak(j)^(-1)*(P(:,:,j)-(ads(j)*(P(:,:,j)*in_xe0')*in_xe0*P(:,:,j))/(lambdak(j)+ads(j)*in_xe0*P(:,:,j)*in_xe0'));
    %psi(:,j)=psi(:,j)+L(:,j)*ek(j);
    P(:,:,j)=lambdak(j)^(-1)*(P(:,:,j)-ads(j)*gk(:,j)*gk(:,j)');
    psi(:,j)=psi(:,j)+muk*sqrt(tauk(j))*ek(j)*ads(j)*gk(:,j);
end
end

