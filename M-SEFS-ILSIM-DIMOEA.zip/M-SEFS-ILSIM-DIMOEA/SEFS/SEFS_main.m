function [jieguo,c,sigma,psi,ad_cum,n_0,ad_time,ad_num,P,add_thr,error,rule_num_dy,error_train,error_test,y_est,y_train,y_test,sigmav,CE,n_0_d,y_min,y_max] = SEFS_main(in_x, out_y, test_x,row,  Da, Db, bound_l, bound_u, lambda, sim_degree, Omega)
%NTITLED2 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The following parts are the main parts of the algorithm.
error=zeros(row,1);
rule_num_dy=zeros(row,1);
error_train=zeros(row,1);
error_test=zeros(row,1);
y_est=zeros(row,1);
y_train=zeros(row,1);
y_test=zeros(row,1);
jieguo = zeros(row,1);
c=in_x(1,:);
n=length(c);
%sigma=zeros(1,n);%0.01*ones(1,n);
y_est(1)=out_y(1);
in_xe=[ones(row,1),in_x];
test_x =[ones(row,1),test_x];
 psi=zeros(n+1,1);%VFF-WRLS
%psi=[0;(1/n)*ones(n,1)];%WRLS
y_est(1)=psi'*in_xe(1,:)';
error(1)=abs(out_y(1)-y_est(1));
P=zeros(n+1,n+1,1);
%Omega=10^4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%VFF-WRLS
P(:,:,1)=Omega*eye(n+1);
sigmav=0;
c1=8;
beta=0.9;
M=10^3;
R_num=1;
[sigmav,P,psi] =VFF_WRLS(n,R_num,1,error(1),1,in_xe(1,:),c1,M,beta,sigmav,P,psi,out_y(1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
w_psix=(psi'*in_xe(1,:)');
 y_train(1)=sum(w_psix);
 error_train(1)=abs(out_y(1)-y_train(1));
 jieguo(1) = sum((psi'*test_x(1,:)'));  % Ԥ��1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CE=error_train(1);
rule_num_dy(1)=rows(c);
y_min=out_y(1);
y_max=out_y(1);

%bound_l=0.5;
%bound_u=0.6;
add_thr=-(bound_u-bound_l)*exp(-CE)+bound_u;
n_0=sqrt(-2*log(add_thr));

n_0_d=n_0;
ad_num=1;
ad_time=1;
ad_cum=1;
%lambda=0.9%forgetting factor for CE

%%%%%%%%%%%%%%%%%%%%

%When x_2 comes, the initial value of the radius could be get.
w_psix=(psi'*in_xe(2,:)');
 y_test(2)=sum(w_psix);
 error_test(2)=out_y(2)-y_test(2);
 
c=[c;in_x(2,:)];
dist_1_2=in_x(1,:)-in_x(2,:);
absdist=zeros(1,n);
sigma=(1/n_0)*norm(dist_1_2)*ones(2,n);%initial radius of the first two clusters
R_num=rows(c);
psi=[psi,psi];
mb=exp(-(ones(R_num,1)*in_x(2,:)-c).^2./(2.*sigma.^2));
ad=prod(mb,2);
w_psix=(psi'*in_xe(2,:)').*(ad/sum(ad));
ads=ad./sum(ad);
y_est(2)=sum(w_psix);
error(2)=abs(out_y(2)-y_est(2));
rule_num_dy(2)=R_num;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%VFF-WRLS
P_p=zeros(n+1,n+1,2);
P_p(:,:,1)=P;
P_p(:,:,2)=Omega*eye(n+1);
P=P_p;
[sigmav,P,psi]=VFF_WRLS(n,R_num,ads,error(2),2,in_xe(2,:),c1,M,beta,sigmav,P,psi,out_y(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
R_num=rows(c);
 mb=exp(-(ones(R_num,1)*in_x(2,:)-c).^2./(2.*sigma.^2));
 ad=prod(mb,2);
 ads=ad./sum(ad);
 w_psix=(psi'*in_xe(2,:)').*ads;
 y_train(2)=sum(w_psix);
 jieguo(2) = sum((psi'*test_x(2,:)').*(ad/sum(ad)));   %���2
 error_train(2)=abs(out_y(2)-y_train(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    CE_p=CE;
    CE=lambda*CE+error_train(2);
    CE_d=abs(CE-CE_p);
    add_thr=-(bound_u-bound_l)*exp(-CE)+bound_u;
    n_0=sqrt(-2*log(add_thr));
    n_0_dn=[n_0_d;n_0];
    n_0_d=n_0_dn; 
ad_num=[ad_num;1];
ad_time=[ad_time;2];
ad_cum=[ad_cum+ad(1);1];
Time_ind=zeros(0,0);
y_min=min(out_y(2),y_min);
y_max=max(out_y(2),y_max);
range_y=abs(y_max-y_min);
ind_merge=zeros(row,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Fuzzy rule adding.
for i=3:row
    R_num=rows(c);
    mb=exp(-(ones(R_num,1)*in_x(i,:)-c).^2./(2.*sigma.^2));
    ad=prod(mb,2);
    ads=ad./sum(ad);
    w_psix=(psi'*in_xe(i,:)').*ads;
    y_test(i)=sum(w_psix);
    error_test(i)=out_y(i)-y_test(i);
    
    mb=exp(-(ones(R_num,1)*in_x(i,:)-c).^2./(2.*sigma.^2));
    ad=prod(mb,2);%ad is the activation degree of each fuzzy rule
    ads=ad./sum(ad);
    ad_cum=ad_cum+ad;%ad_cum stores the cumulative activation degree of each cluster since it been built.
    %ad_cum is used for pruning redundant fuzzy rules
    [admax,admax_id]=max(ad);%select the most activated cluster
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %Add a new fuzzy rule or update the most activated rule accordding to
     %the activation degree.
    [c,sigma,ad_cum,ad_time,add_indicator,ad_num,P,psi]...
        =add_update_EFSN(in_x(i,:),c,sigma,ads,n_0,n,admax,admax_id,ad_cum,ad_time,i,ad_num,P,psi,Omega,add_thr);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Merge two similar fuzzy rules.
    %Merging happens only if there is no new rule added in this step. (i.e. Merging happens when add_indicator=0.)
   R_num=rows(c);
    if (add_indicator==0)&&(R_num~=1)
        
        [c,sigma,ad_cum,ad_time,ad_num,P,psi,ind_merge(i)]=merge_EFSN_L2_revised_final(c,sigma,n,admax_id,ad_cum,ad_time,ad_num,P,psi,R_num,sim_degree,Da,Db);
       
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Computing the model output hat{y_i}
    %Calculate the membership degree
    R_num=rows(c);
    mb=exp(-(ones(R_num,1)*in_x(i,:)-c).^2./(2.*sigma.^2));
    ad=prod(mb,2);
    ads=ad./sum(ad);
    w_psix=(psi'*in_xe(i,:)').*ads;
    y_est(i)=sum(w_psix);
    error(i)=abs(out_y(i)-y_est(i));
    rule_num_dy(i)=R_num;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %VFF-WRLS
   [sigmav,P,psi]=VFF_WRLS(n,R_num,ads,error(i),i,in_xe(i,:),c1,M,beta,sigmav,P,psi,out_y(i));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    mb=exp(-(ones(R_num,1)*in_x(1,:)-c).^2./(2.*sigma.^2));
    ad=prod(mb,2);
    ads=ad./sum(ad);
    w_psix=(psi'*in_xe(i,:)').*ads;
    y_train(i)=sum(w_psix);
    error_train(i)=abs(out_y(i)-y_train(i));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    CE_p=CE;
    CE=lambda*CE+error_train(i);
    CE_d=abs(CE-CE_p);
%     CEM(i)=CE;
    add_thr=-(bound_u-bound_l)*exp(-CE)+bound_u;
    n_0=sqrt(-2*log(add_thr)); 
    n_0_dn=[n_0_d;n_0];
    n_0_d=n_0_dn;
    y_min=min(out_y(i),y_min);
    y_max=max(out_y(i),y_max);
    range_y=abs(y_max-y_min);
    jieguo(i) = sum((psi'*test_x(i,:)').*(ad/sum(ad))); 
  
end

%% Ԥ����һʱ�̵�����
% in_x_1 ΪԤ���ʱ������
% y_test_1 Ϊ����ģ��Ԥ�����һ��Ԥ����
%    in_xe_1=[ones(1,1),in_x_1];
%     R_num=rows(c);
%     mb=exp(-(ones(R_num,1)*in_x_1(1,:)-c).^2./(2.*sigma.^2));
%     ad=prod(mb,2);
%     ads=ad./sum(ad);
%     w_psix=(psi'*in_xe_1(1,:)').*ads;
%     y_test_1=sum(w_psix);
%%



% rule_number=max(rule_num_dy);%rows(c)
% RMSE_train=sqrt(mean((y_train(1:end-1)-out_y(1:end-1)).^2));
% RMSE_test=sqrt(mean((y_test(2:end)-out_y(2:end)).^2));
% SD_train=std(out_y(1:end-1));
% NDEI_train=RMSE_train/SD_train;
% SD_test=std(out_y(2:end));
% NDEI_test=RMSE_test/SD_test;

end

