function result = inpoint(PF,M)
if  M == 4
    f1 = PF(:,1:2);
    f2 = PF(:,3:4);
%     point =  [KER(f1,f1) KER(f1,f2) KER(f2,f1) KER(f2,f2)]; 
    point =  [KER(f1,f2) KER(f2,f1)]; 
else
   f1 = PF(:,1:2);
   f2 = PF(:,3:4); 
   f3 = PF(:,5:6);
   point =  [KER(f1,f1) KER(f1,f2) KER(f1,f3) KER(f2,f1) KER(f2,f2) KER(f2,f3) KER(f3,f1) KER(f3,f2) KER(f3,f3)]; 
end
result = point;
end

