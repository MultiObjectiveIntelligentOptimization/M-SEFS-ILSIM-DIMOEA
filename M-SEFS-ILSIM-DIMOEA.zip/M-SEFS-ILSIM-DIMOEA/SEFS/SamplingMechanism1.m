function f = SamplingMechanism1(PF)
    f = PF + 0.001;
end