function f = SamplingMechanism2(mid,wid,k,N,M,row)
mid1 = zeros(N,M/2);
wid1 = zeros(N,M/2);
f = zeros(N,M);
for i = 1:N   %存了T个区间和中点 现有t=0 t=0.1 t=0.2
   mid1(i,1:M/2) = Prediction_center_ts(mid(i,1).f(:,1:M/2),k,M/2,row,i); 
   wid1(i,1:M/2) = Prediction_center_ts1(wid(i,1).f(:,1:M/2),k,M/2,row,i); 
end

for j = 1:M/2
   f(:,2*j-1:2*j) = [mid1(:,j)-0.5*abs(wid1(:,j)),mid1(:,j)+0.5*abs(wid1(:,j))];
end
end
