function [cnew,sigmanew,ad_numnew,ad_cumnew,ad_timenew,Pnew,psinew] =merged_cs_EFS(c,sigma,admax_id,comc_indx,ad_num,ad_cum,ad_time,P,psi,n)
%Compute the center and the radius of the merged two fuzzy sets.
len_comc=length(comc_indx);
if len_comc==0
    cnew=c;
    sigmanew=sigma;
    ad_numnew=ad_num;
    ad_cumnew=ad_cum;
    ad_timenew=ad_time;
    Pnew=P;
    psinew=psi;
else
    cnew=(ad_num(admax_id)*c(admax_id,:)+sum((ad_num(comc_indx)*ones(1,n)).*c(comc_indx,:),1))./(ad_num(admax_id)+sum(ad_num(comc_indx)));
    sigmanew=sqrt((ad_num(admax_id)*(sigma(admax_id,:).^2+(c(admax_id,:)-cnew).^2)...
            +sum((ad_num(comc_indx)*ones(1,n)).*(sigma(comc_indx,:).^2+(c(comc_indx,:)-ones(len_comc,1)*cnew).^2),1))./...
            (ad_num(admax_id)+sum(ad_num(comc_indx))));
    ad_numnew=ad_num(admax_id)+sum(ad_num(comc_indx));
    ad_cumnew=ad_cum(admax_id)+sum(ad_cum(comc_indx));
    ad_timenew=max([ad_time(admax_id);ad_time(comc_indx)]);
    Pweight=ones(n+1,n+1,len_comc);
    for i=1:len_comc
        Pweight(:,:,i)=ad_num(comc_indx(i))*P(:,:,comc_indx(i));
    end
    Pnew=(ad_num(admax_id)*P(:,:,admax_id)+sum(Pweight,3))./(ad_num(admax_id)+sum(ad_num(comc_indx)));
    psinew=(ad_num(admax_id)*psi(:,admax_id)+sum(ones(n+1,1)*ad_num(comc_indx)'.*psi(:,comc_indx),2))./(ad_num(admax_id)+sum(ad_num(comc_indx)));
end
end

