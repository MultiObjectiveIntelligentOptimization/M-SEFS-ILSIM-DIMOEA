function [c_merge,sigma_merge,ad_cum_merge,ad_time_merge,ad_num_merge,P_merge,psi_merge]...
    =merge_result_EFSN(c,sigma,R_num,admax_id,comc_indx,ad_cum,ad_time,ad_num,P,psi,n)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
len_comc=length(comc_indx);
if len_comc==0
    c_merge=c;
    sigma_merge=sigma;
    ad_num_merge=ad_num;
    ad_cum_merge=ad_cum;
    ad_time_merge=ad_time;
    P_merge=P;
    psi_merge=psi;
else
    [c(admax_id,:),sigma(admax_id,:),ad_num(admax_id),ad_cum(admax_id),ad_time(admax_id),P(:,:,admax_id),psi(:,admax_id)]...
            =merged_cs_EFS(c,sigma,admax_id,comc_indx,ad_num,ad_cum,ad_time,P,psi,n);
     rem_indx=setdiff((1:1:R_num),comc_indx);
     c_merge=c(rem_indx,:);
     sigma_merge=sigma(rem_indx,:);
     ad_num_merge=ad_num(rem_indx);
     ad_cum_merge=ad_cum(rem_indx);
     ad_time_merge=ad_time(rem_indx);
     P_merge=P(:,:,rem_indx);
     psi_merge=psi(:,rem_indx);
end
end

