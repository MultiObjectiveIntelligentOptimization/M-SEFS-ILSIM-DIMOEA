function [c_merge,sigma_merge,ad_cum_merge,ad_time_merge,ad_num_merge,P_merge,psi_merge,ind_merge]...
    =merge_EFSN_L2_revised_final(c,sigma,n,admax_id,ad_cum,ad_time,ad_num,P,psi,R_num,sim_degree,Da,Db)%,thr_cons,range_y)
%Merging two similar fuzzy rules by using \theta_{i_{1}}/\theta_{i_{2}}.
%cut_a, cut_b are two vectors storing the 0.95 \alpha-cut of each fuzzy set A_i_{i}j (A_{i_{2}j}) in the i_{1}-th and i_{2}-th rule.
%[a,b] are the domain of G_{j}.
%Domain is [a1,b1]X[a2,b2]X...X[an,bn].
% Similarity degree is computed realtively accurate.
%The integral in merge_EFS_L2 is computed on RXRX...XR
%Da,Db are the lower and upper bounds of the domain(Da<Db)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
indicate_in=1;
while (indicate_in==1)&&(size(c,1)>1)
    ind_merge=0;
    similarity=zeros(R_num,1);
    %Make transformation of Da and Db.
    Da_id=sigma(admax_id,:).*Da+c(admax_id,:);
    Db_id=sigma(admax_id,:).*Db+c(admax_id,:);

    Aadmax_id=prod(sigma(admax_id,:).*G_fun(Da_id,Db_id));
    for i=1:R_num
        if i~=admax_id
            A0=((1/2)*sqrt(pi))^n;
            %Make transformation of the domain.
            %tic
            Da_i=sigma(i,:).*Da+c(i,:);
            Db_i=sigma(i,:).*Db+c(i,:);

            A1=prod(sigma(i,:).*G_fun(Da_i,Db_i));
            Da_i=sqrt(2)*sigma(i,:).*sigma(admax_id,:).*Da./sqrt(sigma(i,:).^2+sigma(admax_id,:).^2)+...
                (sigma(i,:).^2.*c(admax_id,:)+sigma(admax_id,:).^2.*c(i,:))./(sigma(i,:).^2+sigma(admax_id,:).^2);
            Db_i=sqrt(2)*sigma(i,:).*sigma(admax_id,:).*Db./sqrt(sigma(i,:).^2+sigma(admax_id,:).^2)+...
                (sigma(i,:).^2.*c(admax_id,:)+sigma(admax_id,:).^2.*c(i,:))./(sigma(i,:).^2+sigma(admax_id,:).^2);

            A2=prod(sqrt(2)*sigma(i,:).*sigma(admax_id,:)./sqrt(sigma(i,:).^2+...
                 sigma(admax_id,:).^2).*exp(-(c(i,:)-c(admax_id,:)).^2./(2*(sigma(i,:).^2+sigma(admax_id,:).^2))).*G_fun(Da_i,Db_i));
            A3=A1+Aadmax_id-2*A2;
            A=A0*A3;
            similarity(i)=1/(1+sqrt(A));%revised sqrt(A) to 1/(1+sqrt(A))
          
        end
    end
    j=1;
    similarity_tem=zeros(R_num-1,1);   
    for i=1:R_num
        if i~=admax_id 
           similarity_tem(j)=similarity(i);
           j=j+1;
        end
    end
    max_value=max(similarity_tem);
    max_index=find(similarity==max_value);
    max_index=max_index(1); 
    if (max_value>sim_degree)
        m_ind=max_index;
        ind_merge=1;
    else
        m_ind=[];
    end
    [c,sigma,ad_cum,ad_time,ad_num,P,psi]...
        =merge_result_EFSN(c,sigma,R_num,admax_id,m_ind,ad_cum,ad_time,ad_num,P,psi,n);
    if (max_index<admax_id)
        admax_id=admax_id-1;
    end
        
    if (ind_merge==0)
        indicate_in=0;
    else
        indicate_in=1;
        R_num=R_num-1;
    end
        
        


    
    
end

c_merge=c;
sigma_merge=sigma;
ad_cum_merge=ad_cum;
ad_time_merge=ad_time;
ad_num_merge=ad_num;
P_merge=P;
psi_merge=psi;


 
% m_ind=zeros(0,1);
% for i=1:R_num
%     if (similarity(i)>sim_degree)&&(i~=admax_id)%reviesed < to >
%         m_ind0=m_ind;
%         m_ind=[m_ind0;i];
%         ind_merge=1;
%     end
% end


   

    


end



