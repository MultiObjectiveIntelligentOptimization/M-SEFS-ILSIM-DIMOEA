function pre = prediction(pf,ps,pf_p,k,row,j)
global canshu2
Omega=10^4;
bound_l=0.5;
bound_u=0.6;
lambda=0.9;
sim_degree=0.7;
jieguo = zeros(size(pf,1),1);
if k == 1 
    for i = 1:size(pf,1)
        in_x = pf;
        in_y = ps;        
        Da=min(in_x);
        Db=max(in_x);
        test = pf_p;
        test_x=[ones(row,1),test];
        [result,c,sigma,psi,ad_cum,n_0,ad_time,ad_num,P,add_thr,error,rule_num_dy,error_train,error_test,y_est,y_train,y_test,sigmav,CE,n_0_d,y_min,y_max] = SEFS_main(in_x, in_y, test_x,row,  Da, Db, bound_l, bound_u, lambda, sim_degree, Omega);
        canshu2(j,1).c = c;canshu2(j,1).ad = ad_cum; canshu2(j,1).n = n_0;canshu2(j,1).time = ad_time;canshu2(j,1).num = ad_num;
        canshu2(j,1).sigma = sigma;canshu2(j,1).P = P;canshu2(j,1).thr = add_thr;canshu2(j,1).error = error;canshu2(j,1).r = rule_num_dy;
        canshu2(j,1).et = error_train; canshu2(j,1).ett = error_test; canshu2(j,1).ye = y_est; canshu2(j,1).yt = y_train; canshu2(j,1).ytt = y_test;
        canshu2(j,1).psi = psi;canshu2(j,1).Da = Da;canshu2(j,1).Db = Db;canshu2(j,1).sigmav = sigmav;canshu2(j,1).CE = CE;canshu2(j,1).n0 = n_0_d; canshu2(j,1).min = y_min; canshu2(j,1).max = y_max;
        jieguo(i) = result;
    end
elseif k >= 2
    for i = 1:size(pf,1)
        in_x = pf;
        in_y = ps;      
        Da=min(canshu2(j,i).Da,in_x);
        Db=max(canshu2(j,i).Db,in_x);
        test = data(i,k);
        test_x = [ones(1,1),test];
        [result,c,sigma,psi,ad_cum,n_0,ad_time,ad_num,P,add_thr,error,rule_num_dy,error_train,error_test,y_est,y_train,y_test,sigmav,CE,n_0_d,y_min,y_max] = SEFS_main2(in_x, in_y,test_x, Da, Db, bound_l, bound_u, lambda, sim_degree, Omega,k-1,canshu2(j,i).c,canshu2(j,i).sigma,canshu2(j,i).psi,canshu2(j,i).ad,canshu2(j,i).n,canshu2(j,i).time,canshu2(j,i).num,canshu2(j,i).P,canshu2(j,i).thr,canshu2(j,i).error,canshu2(j,i).r,canshu2(j,i).et,canshu2(j,i).ett,canshu2(j,i).ye,canshu2(j,i).yt,canshu2(j,i).ytt,canshu2(j,i).sigmav,canshu2(j,i).CE,canshu2(j,i).n0,canshu2(j,i).min,canshu2(j,i).max);
        canshu2(j,1).c = c;canshu2(j,1).ad = ad_cum; canshu2(j,1).n = n_0;canshu2(j,1).time = ad_time;canshu2(j,1).num = ad_num;
        canshu2(j,1).sigma = sigma;canshu2(j,1).P = P;canshu2(j,1).thr = add_thr;canshu2(j,1).error = error;canshu2(j,1).r = rule_num_dy;
        canshu2(j,1).et = error_train; canshu2(j,1).ett = error_test; canshu2(j,1).ye = y_est; canshu2(j,1).yt = y_train; canshu2(j,1).ytt = y_test;
        canshu2(j,1).psi = psi;canshu2(j,1).Da = Da;canshu2(j,1).Db = Db;canshu2(j,1).sigmav = sigmav;canshu2(j,1).CE = CE;canshu2(j,1).n0 = n_0_d; canshu2(j,1).min = y_min; canshu2(j,1).max = y_max;        jieguo(i) = result;
    end 
end
for i = 1:size(pf,1)
   if isnan(jieguo(i))
       jieguo(i) = ps(i);
   end
end
pre = jieguo;
end



