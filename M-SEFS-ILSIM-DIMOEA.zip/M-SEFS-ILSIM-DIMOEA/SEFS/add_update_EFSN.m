function [c,sigma, ad_cum,ad_time,add_indicator,ad_num,P,psi]...
    =add_update_EFSN(inx,c,sigma,ads,n_0,n,admax,admax_id,ad_cum,ad_time,T,ad_num,P,psi,Omega,ad_thr)
%fuzzy rule adding and updating accordding to the activation degree
%ad_thr=exp(-n*(n_0^2)/2);%Compute the threshold for fuzzy rule adding.
%m0=sqrt(-2*log(bound_u));
if admax>=ad_thr
    %Update the nearest fuzzy rule center, radius, number of data, 
    ad_num(admax_id)=ad_num(admax_id)+1;
    if (admax~=1)
        c_0=c;
        c(admax_id,:)=c(admax_id,:)+(inx-c(admax_id,:))./ad_num(admax_id);   
        sigma(admax_id,:)=sqrt(sigma(admax_id,:).^2+...
            ((ad_num(admax_id)-1)*(c_0(admax_id,:)-c(admax_id,:)).^2+(inx-c(admax_id,:)).^2-sigma(admax_id,:).^2)./ad_num(admax_id));
    end
    add_indicator=0;
else
    c_new=[c;zeros(1,n)];
    sigma_new=[sigma;zeros(1,n)];
    c_new(end,:)=inx;
    sigma_new(end,:)=(norm(c_new(end,:)-c(admax_id,:))/n_0)*ones(1,n);
    c=c_new;
    R_num=rows(c);
    sigma=sigma_new;
    ad_cum=[ad_cum;1];
    ad_time=[ad_time;T];
    add_indicator=1;
    ad_num=[ad_num;1];
    P_new=zeros(n+1,n+1,R_num);
    P_new(:,:,1:R_num-1)=P;
    P_new(:,:,R_num)=Omega*eye(n+1);
    P=P_new;
    psi_add=zeros(n+1,R_num-1);
%%%%%%%%%%%%%%
%SEFS
%     for i=1:R_num-1
%         psi_add(:,i)=ads(i)*psi(:,i);
%     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i=1:R_num-1
       norm_c(i)= norm(c(i,:)-c(end,:));
    end
    norm_c=norm_c/sum(norm_c);
    for i=1:R_num-1
       psi_add(:,i)= norm_c(i)*psi(:,i);
    end
    psi=[psi,sum(psi_add,2)];
%%%%%%%%%%%%%%%%%
    %psi=[psi,mean(psi_add,2)];
end

end

