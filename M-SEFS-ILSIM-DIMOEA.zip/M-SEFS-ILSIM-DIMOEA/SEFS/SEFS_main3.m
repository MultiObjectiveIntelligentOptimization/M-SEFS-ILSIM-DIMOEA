function [result,c,sigma,psi,ad_cum,n_0,ad_time,ad_num,P,add_thr,error,rule_num_dy,error_train,error_test,y_est,y_train,y_test,sigmav,CE,n_0_d,y_min,y_max,in_xe] = SEFS_main3(in_x, out_y,test_x, row,  Da, Db, bound_l, bound_u, lambda, sim_degree, Omega)
 %The following parts are the main parts of the algorithm.
error=zeros(row,1);
rule_num_dy=zeros(row,1);
error_train=zeros(row,1);
error_test=zeros(row,1);
y_est=zeros(row,1);
y_train=zeros(row,1);
y_test=zeros(row,1);
c=in_x(1,:);
n=length(c);
%sigma=zeros(1,n);%0.01*ones(1,n);
y_est(1)=out_y(1);
in_xe=[ones(2,1),in_x];
 psi=zeros(n+1,1);%VFF-WRLS
%psi=[0;(1/n)*ones(n,1)];%WRLS
y_est(1)=psi'*in_xe(1,:)';
error(1)=abs(out_y(1)-y_est(1));
P=zeros(n+1,n+1,1);
%Omega=10^4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%VFF-WRLS
P(:,:,1)=Omega*eye(n+1);
sigmav=0;
c1=8;
beta=0.9;
M=10^3;
R_num=1;
[sigmav,P,psi] =VFF_WRLS(n,R_num,1,error(1),1,in_xe(1,:),c1,M,beta,sigmav,P,psi,out_y(1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
w_psix=(psi'*in_xe(1,:)');
 y_train(1)=sum(w_psix);
 error_train(1)=abs(out_y(1)-y_train(1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CE=error_train(1);
rule_num_dy(1)=rows(c);
y_min=out_y(1);
y_max=out_y(1);

%bound_l=0.5;
%bound_u=0.6;
add_thr=-(bound_u-bound_l)*exp(-CE)+bound_u;
n_0=sqrt(-2*log(add_thr));

n_0_d=n_0;
ad_num=1;
ad_time=1;
ad_cum=1;
%lambda=0.9%forgetting factor for CE

%%%%%%%%%%%%%%%%%%%%

%When x_2 comes, the initial value of the radius could be get.
w_psix=(psi'*in_xe(2,:)');
y_test(2)=sum(w_psix);
error_test(2)=out_y(2)-y_test(2);
 
c=[c;in_x(2,:)];
dist_1_2=in_x(1,:)-in_x(2,:);
% absdist=zeros(1,n);
sigma=(1/n_0)*norm(dist_1_2)*ones(2,n);%initial radius of the first two clusters
R_num=rows(c);
psi=[psi,psi];

mb=exp(-(ones(R_num,1)*in_x(2,:)-c).^2./(2.*sigma.^2));

ad=prod(mb,2);
w_psix=(psi'*in_xe(2,:)').*(ad/sum(ad));
ads=ad./sum(ad);
y_est(2)=sum(w_psix);
error(2)=abs(out_y(2)-y_est(2));
rule_num_dy(2)=R_num;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%VFF-WRLS
P_p=zeros(n+1,n+1,2);
P_p(:,:,1)=P;
P_p(:,:,2)=Omega*eye(n+1);
P=P_p;
[sigmav,P,psi]=VFF_WRLS(n,R_num,ads,error(2),2,in_xe(2,:),c1,M,beta,sigmav,P,psi,out_y(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
R_num=rows(c);
 mb=exp(-(ones(R_num,1)*in_x(2,:)-c).^2./(2.*sigma.^2));
 ad=prod(mb,2);
 ads=ad./sum(ad);
 w_psix=(psi'*in_xe(2,:)').*ads;
 y_train(2)=sum(w_psix);
 error_train(2)=abs(out_y(2)-y_train(2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     CE_p=CE;
    CE=lambda*CE+error_train(2);
%     CE_d=abs(CE-CE_p);
    add_thr=-(bound_u-bound_l)*exp(-CE)+bound_u;
    n_0=sqrt(-2*log(add_thr));
    n_0_dn=[n_0_d;n_0];
    n_0_d=n_0_dn; 
ad_num=[ad_num;1];
ad_time=[ad_time;2];
ad_cum=[ad_cum+ad(1);1];
% Time_ind=zeros(0,0);
y_min=min(out_y(2),y_min);
y_max=max(out_y(2),y_max);
% range_y=abs(y_max-y_min);
% ind_merge=zeros(row,1);
result = sum((psi'*test_x(1,:)').*ads);
end