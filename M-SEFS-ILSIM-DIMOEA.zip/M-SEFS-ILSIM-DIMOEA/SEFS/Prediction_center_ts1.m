function pre = Prediction_center_ts1(C,k,V,row,j)
global canshu1
Omega=10^4;%协方差矩阵初始化
bound_l=0.5; %自适应阈值的边界
bound_u=0.6;
lambda=0.9;%遗忘因子
sim_degree=0.7;
jieguo = zeros(1,V);
data = C(1:k,:)';
if k == 3 
    for i = 1:V
        in_x = [data(i,1);data(i,2)];
        in_y = [data(i,2);data(i,3)];        
        Da=min(in_x);%网络参数可以一样，但是输入不能一样，中点和宽度的数据不一样
        Db=max(in_x);
        test = data(i,3);
        test_x=[ones(1,1),test];
        [result,c,sigma,psi,ad_cum,n_0,ad_time,ad_num,P,add_thr,error,rule_num_dy,error_train,error_test,y_est,y_train,y_test,sigmav,CE,n_0_d,y_min,y_max] = SEFS_main1(in_x, in_y, test_x, row, Da, Db, bound_l, bound_u, lambda, sim_degree, Omega,k-1,canshu1(j,i).c,canshu1(j,i).sigma,canshu1(j,i).psi,canshu1(j,i).ad,canshu1(j,i).n,canshu1(j,i).time,canshu1(j,i).num,canshu1(j,i).P,canshu1(j,i).thr,canshu1(j,i).error,canshu1(j,i).r,canshu1(j,i).et,canshu1(j,i).ett,canshu1(j,i).ye,canshu1(j,i).yt,canshu1(j,i).ytt,canshu1(j,i).sigmav,canshu1(j,i).CE,canshu1(j,i).n0,canshu1(j,i).min,canshu1(j,i).max,k,i);
        canshu1(j,i).c = c;canshu1(j,i).ad = ad_cum; canshu1(j,i).n = n_0;canshu1(j,i).time = ad_time;canshu1(j,i).num = ad_num;
        canshu1(j,i).c = c;canshu1(j,i).ad = ad_cum; canshu1(j,i).n = n_0;canshu1(j,i).time = ad_time;canshu1(j,i).num = ad_num;
        canshu1(j,i).sigma = sigma;canshu1(j,i).P = P;canshu1(j,i).thr = add_thr;canshu1(j,i).error = error;canshu1(j,i).r = rule_num_dy;
        canshu1(j,i).et = error_train; canshu1(j,i).ett = error_test; canshu1(j,i).ye = y_est; canshu1(j,i).yt = y_train; canshu1(j,i).ytt = y_test;
        canshu1(j,i).psi = psi;canshu1(j,i).Da = Da;canshu1(j,i).Db = Db;canshu1(j,i).sigmav = sigmav;canshu1(j,i).CE = CE;canshu1(j,i).n0 = n_0_d; canshu1(j,i).min = y_min; canshu1(j,i).max = y_max;
        jieguo(i) = result;
    end
elseif k >= 4
    for i = 1:V
        in_x = data(i,k-1);
        in_y = data(i,k);      
        Da=min(canshu1(j,i).Da,in_x);
        Db=max(canshu1(j,i).Db,in_x);
        test = data(i,k);
        test_x = [ones(1,1),test];
        [result,c,sigma,psi,ad_cum,n_0,ad_time,ad_num,P,add_thr,error,rule_num_dy,error_train,error_test,y_est,y_train,y_test,sigmav,CE,n_0_d,y_min,y_max] = SEFS_main2(in_x, in_y,test_x, Da, Db, bound_l, bound_u, lambda, sim_degree, Omega,k-1,canshu1(j,i).c,canshu1(j,i).sigma,canshu1(j,i).psi,canshu1(j,i).ad,canshu1(j,i).n,canshu1(j,i).time,canshu1(j,i).num,canshu1(j,i).P,canshu1(j,i).thr,canshu1(j,i).error,canshu1(j,i).r,canshu1(j,i).et,canshu1(j,i).ett,canshu1(j,i).ye,canshu1(j,i).yt,canshu1(j,i).ytt,canshu1(j,i).sigmav,canshu1(j,i).CE,canshu1(j,i).n0,canshu1(j,i).min,canshu1(j,i).max,k,i);
        canshu1(j,i).c = c;canshu1(j,i).ad = ad_cum; canshu1(j,i).n = n_0;canshu1(j,i).time = ad_time;canshu1(j,i).num = ad_num;
        canshu1(j,i).sigma = sigma;canshu1(j,i).P = P;canshu1(j,i).thr = add_thr;canshu1(j,i).error = error;canshu1(j,i).r = rule_num_dy;
        canshu1(j,i).et = error_train; canshu1(j,i).ett = error_test; canshu1(j,i).ye = y_est; canshu1(j,i).yt = y_train; canshu1(j,i).ytt = y_test;
        canshu1(j,i).psi = psi;canshu1(j,i).Da = Da;canshu1(j,i).Db = Db;canshu1(j,i).sigmav = sigmav;canshu1(j,i).CE = CE;canshu1(j,i).n0 = n_0_d; canshu1(j,i).min = y_min; canshu1(j,i).max = y_max;
        jieguo(i) = result;
    end 
end
for i = 1:V
   if isnan(jieguo(i))
       jieguo(i) = C(k,i);
   end
end
pre = jieguo;
end

