%% ZDT1 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='ZDT1';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20;
    Gen = 20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive'); 
%% ZDT3 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='ZDT3';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20;Gen = 20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive'); 
%% FDA1 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='FDA1';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20; Gen = 20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive'); 
%% FDA3 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='FDA3';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20; Gen = 20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive'); 
%% FDA4 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='FDA4';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:8];g2=[9:15];
    group1=g1;group2=[1 g2];
    pop=100;gen=20;Gen=20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive'); 
%% FDA5 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='FDA5';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:8];g2=[9:15];
    group1=g1;group2=[1 g2];
    pop=100;gen=20;Gen = 20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive'); 
 %% DF1 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='DF1';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20;Gen=20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive'); 
 %% DF2 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='DF2';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20;Gen=20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive'); 
%% DF3 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='DF3';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20; Gen = 20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive'); 
%% DF7 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='DF7';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20;Gen = 20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive');
%% HE2 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='HE2';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20;Gen = 20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method, Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive');
%% DSW1 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='DSW1';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:8];g2=[9:15];
    group1=g1;group2=[1 g2];
    pop=100;gen=20; Gen=20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive');
%% DSW2 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='DSW2';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:8];g2=[9:15];
    group1=g1;group2=[1 g2];
    pop=100;gen=20;Gen=20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive');
%% UDF2 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='UDF2';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20; Gen = 20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive');
%% UDF5 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='UDF5';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:15];g2=[];
    group1=g1;group2=[1 g2];
    pop=100;gen=20;Gen = 20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive');
%% FDA4 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='FDA4.1';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2];g2=[3:12];
    group1=g1;group2=[1 g2];
    pop=105;gen=20;Gen=20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive');
%% FDA5 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='FDA5.1';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2];g2=[3:12];
    group1=g1;group2=[1 g2];
    pop=105;gen=20;Gen=20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive');
%% SJY1 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    clear;clc;
    name='SJY1';
    method = 'ILSIM';
    num_of_runs=15;                                                         %设置总的运行次数
    tt=0:0.1:5;                                                            %时间变量的取值范围，为向量
    g1=[2:3];g2=[4:12];
    group1=g1;group2=[1 g2];
    pop=105;gen=20;Gen=20;
    nVar=size(group1,2)+size(group2,2);                                    %自变量维数
    T = 10;                                                                %邻域权重大小
for runs = 1:num_of_runs                                                   %独立运行num_of_runs次  
    fprintf('总循环次数:%d\n',runs)
   [metric_staticIP,archive_staticIP]=DIMOEAD(name,tt,g1,g2,nVar,pop,gen,runs,T,group1,group2,method,Gen);
    staticIP_metric(runs,1)=metric_staticIP;
    staticIP_archive(runs,1).staticIP=archive_staticIP;
end
    str = strcat(name,'_metric_staticIP','.mat');
    save(str,'staticIP_metric');
    str=strcat(name,'_archive_staticIP','.mat');
    save(str,'staticIP_archive');
    