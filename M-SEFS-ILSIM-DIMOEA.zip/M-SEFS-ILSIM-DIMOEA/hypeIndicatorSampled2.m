% HYPEINDICATORSAMPLED calculates the HypE fitness of maximum problem
%   HYPEINDICATORSAMPLED( POINTS, BOUNDS, K, NROFSAMPLES  ) 
%   samples the HypE fitness values for objective vectors POINTS. 
%
%   POINTS:      objective vectors as rows, all to be minimized
%   BOUNDS:      reference point
%   K:           parameter of HypE
%   NROFSAMPLES: nr of samples to be used
%
%   Example: f =  hypeIndicatorExact( [1 3; 3 1], [4 4], 1, 10000 )

function F = hypeIndicatorSampled2( points, bounds, k, nrOfSamples)
    [nrP, dim] = size(points);                                             %nrpΪ��Ⱥ��ģ��dimΪĿ�꺯������
    F = zeros(1,nrP);
    
    alpha = zeros(1,nrP);
    for i = 1 : k
        j = 1:i-1;
        alpha(i) = prod( (k-j) ./ (nrP - j ) )./i;                         %����alfaֵ
    end  
    
    
    if( length(bounds) == 1 )
        bounds = repmat( bounds,1, dim );   
    end
    
    BoxL = max(points);
    
    S = rand(nrOfSamples,dim)*diag(BoxL-bounds) ...
    + ones( nrOfSamples,dim)*diag(bounds);                                 %�ڲ����ռ����������

    dominated = zeros( nrOfSamples, 1 );
    for j = 1 : nrP
        B = repmat(points(j,:),nrOfSamples,1)-S;                           %����������ڵ�j�����λ��
        ind = find( sum( B >= 0, 2) == dim);                               %sum( B >= 0, 2) == dim��ʾ��j����ռ��
        dominated(ind) = dominated(ind) + 1;                               %ÿ�������㱻ռ�ŵĴ���
    end
    
    for j = 1 : nrP
        B = repmat(points(j,:),nrOfSamples,1)-S;
        ind = find( sum( B >= 0, 2) == dim);
        x = dominated(ind);        
        F(j) = sum(  alpha(x)  );
    end    
    F = F'*prod(BoxL-bounds)/nrOfSamples;
    

    