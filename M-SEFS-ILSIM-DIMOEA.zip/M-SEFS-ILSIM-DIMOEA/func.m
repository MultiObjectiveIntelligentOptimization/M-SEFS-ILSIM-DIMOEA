function result = func(name,x,nObj,nVar,t,g1,g2,new_f)
% result =[];
f = evaluate_objective(name, x, nObj, nVar, t, g1, g2);
summ = 0;
for i = 1:nObj/2
    cha = [f(2*i-1)-new_f(2*i),f(2*i)-new_f(2*i-1)];
    if cha(1) >=0 && cha(1) <= cha(2)
        re = cha.^2;
    elseif cha(2) >= cha(1) && cha(2) <=0
        re = [cha(2)^2,cha(1)^2];
    else
        re = [0,max(cha.^2)];
    end
    summ = summ + re;
%     summ = summ + (infsup(f(2*i-1),f(2*i))-infsup(new_f(2*i-1),new_f(2*i)))^2;
end
result = summ;
% result(1) = inf(summ);
% result(2) = sup(summ);
end

