function f = initialize_variables(name,N, M, V, min_range, max_range, t, g1, g2)

min = min_range;
max = max_range;

K = M + V;

%% ��ʼ����Ⱥ
for i = 1 : N
    for j = 1 : V
        f(i,j) = (min(j) + (max(j) - min(j))*rand(1));
    end
    f(i,V + 1: K) = (evaluate_objective(name,f(i,:), M, V, t, g1, g2));
end










