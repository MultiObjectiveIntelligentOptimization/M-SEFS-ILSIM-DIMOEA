function f = evaluate_objective(name, x, nObj, nVar, t, g1, g2)
c1=infsup(0.9,1);                                                          %c1ΪĿ�꺯����x1��Ӧ���������ȡֵ,��igd�����е�ptrue�еı���һ�¡�
switch name
    %% DMOPϵ��
    case {'DMOP1'}
        summ=0;
        c(1)=c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(i*pi*t)),0.5+0.45*abs(sin(i*pi*t)));
            mi=min(0.45*abs(sin(i*pi*t)),0.5+0.45*abs(sin(i*pi*t)));
            c(i)=infsup(mi,ma);
            summ=summ+c(i)*(x(i)-mid(c(i)))^2;
        end
        f=[];
        g_xm=1+9*summ;
        Ht=0.75*sin(0.5*pi*t)+1.25;
        f1=c(1)*x(1);
        h=1-(f1/g_xm)^Ht;
        f2 = g_xm*h;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% ZDTϵ��
    %% *********************** ZDT1���Ժ���*****************
    case {'ZDT1'}
        summ=0;
        M=nObj/2;                                                          %MΪʵ��Ŀ�꺯���ĸ�����nObjΪʵ��Ŀ����Ŀ��2����
        c(1)=c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(i*pi*t)),0.5+0.45*abs(sin(i*pi*t)));
            mi=min(0.45*abs(sin(i*pi*t)),0.5+0.45*abs(sin(i*pi*t)));
            c(i)=infsup(mi,ma);
            summ=summ+c(i)*(x(i)-mid(c(i)))^2;
        end
        f=[];
        g_xm=1+9*summ/(nVar-1);
        f1=c(1)*x(1);
        f2=g_xm*(1-sqrt(f1/g_xm))^(t+0.1);

        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
     %% *********************** ZDT3���Ժ���*****************
     case {'ZDT3'}   
        summ=0;
        M=nObj/2;                                                          %MΪʵ��Ŀ�꺯���ĸ�����nObjΪʵ��Ŀ����Ŀ��2����
        c(1)=c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(i*pi*t)),0.5+0.45*abs(sin(i*pi*t)));
            mi=min(0.45*abs(sin(i*pi*t)),0.5+0.45*abs(sin(i*pi*t)));
            c(i)=infsup(mi,ma);
            summ=summ+c(i)*(x(i)-mid(c(i)))^2;
        end
        f=[];
        g_xm=1+9*summ/(nVar-1);
        f1=c(1)*x(1);
        f2=g_xm*((2-sqrt(f1/g_xm)-(f1/g_xm)*sin(10*pi*f1)));  
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);    
     %% *********************** ZDT4���Ժ���*****************
     case {'ZDT4'}
         M=nObj/2; 
         c(1)=c1;
         summ=0;
         for i=2:nVar
             ma=max(0.45*abs(sin(i*pi*t)),0.5+0.45*abs(sin(i*pi*t)));
             mi=min(0.45*abs(sin(i*pi*t)),0.5+0.45*abs(sin(i*pi*t)));
             c(i)=infsup(mi,ma);
             summ=summ+c(i)*(x(i))^2-10*cos(4*pi*c(i)*x(i));
         end
         g_xm=1+summ+10*(nVar-1);
         f=[];
         f1=c(1)*x(1);
         f2=g_xm*(1-sqrt(f1/g_xm));
         f(1)=inf(f1);
         f(2)=sup(f1);
         f(3)=inf(f2);
         f(4)=sup(f2);
    %% FDAϵ��
    %% *********************** FDA1���Ժ���*****************
    case{'FDA1'}
        c(1)=c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);
        end
        g_xm=1+sum(c(2:nVar).*(x(2:nVar)-mid(c(2:nVar))).^2);
        f1=c(1)*x(1);
        h=1-sqrt(f1./g_xm);
        f2=g_xm*h;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
   %% *********************** FDA2���Ժ���*****************   
    case{'FDA2'}
        c(1)=c1;
        ma=max(0.45*abs(sin(pi*t)),0.5+0.45*abs(sin(pi*t)));
        mi=min(0.45*abs(sin(pi*t)),0.5+0.45*abs(sin(pi*t)));
        c(2)=infsup(mi,ma);
        g_xm=1+sum(x(g1).^2);
        f1=c(1)*x(1);
        Ht=mid(c(2));
        H2t=(Ht+sum((x(g2)-Ht).^2))^(-1);
        h=1-(f1/g_xm)^(H2t);
        f2=g_xm*h;       
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    case {'FDA2.1'}
       c(1) = c1;
       for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);
       end
       Ht = 0.75+0.75*sin(0.5*pi*t);
       H2t = (Ht + sum((x(g2)-Ht).^2)).^-1;
       f1 = c1*x(1);
       g = 1 + sum(c(g1).*(x(g1)).^2);
       h = 1 - (f1/g)^H2t;
       f2 = g*h;
       f(1)=inf(f1);
       f(2)=sup(f1);
       f(3)=inf(f2);
       f(4)=sup(f2);
    %% *********************** FDA3���Ժ���*****************    
    case{'FDA3'}  
       c(1) = c1;
       for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);
       end
        Ft=10^(2*sin(0.5*pi*t));
        f1=c(1)*(x(1).^Ft);
        Gt=abs(sin(0.5*pi*t));
        g_xm=1+Gt+sum(c(2:nVar).*(x(2:nVar)-Gt).^2);
        h=1-sqrt(f1./g_xm);
        f2=g_xm*h;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2); 
        f(4)=sup(f2);
    %% *********************** FDA4���Ժ���*****************    
    case {'FDA4'}   
        c(1)=c1;
        c(g1)=infsup(1,1);
        for i=1:numel(g2)
            j=g2(i);
            ma=max(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            mi=min(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            c(j)=infsup(mi,ma);
        end
        g11=sum(c(g1).*(x(g1)-0.5).^2);
        g22=sum(c(g2).*(x(g2)-mid(c(g2))).^2);
        g_xm=g11+g22;
        f1=(1+g_xm)*cos(c(1)*x(1)*(pi/2));
        f2=(1+g_xm)*sin(c(1)*x(1)*(pi/2));
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% *********************** FDA5���Ժ���*****************
    case 'FDA5'
        c(1)=c1;
        c(g1)=infsup(1,1);
        for i=1:numel(g2)
            j=g2(i);
            ma=max(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            mi=min(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            c(j)=infsup(mi,ma);
        end
        Gt=abs(sin(0.5*pi*t));
        g11=sum(c(g1).*(x(g1)-0.5).^2);
        g22=Gt+sum(c(g2).*(x(g2)-mid(c(g2))).^2);
        F=1+100*(sin(0.5*pi*t))^4;
        f1=(1+g11)*cos(0.5*pi*x(1))+(1+g22)*cos(0.5*pi*c(1)*x(1)^F);
        f2=(1+g11)*sin(0.5*pi*x(1))+(1+g22)*sin(0.5*pi*c(1)*x(1)^F);

        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
   %% DSWϵ��
   %% *********************** DSW1���Ժ���*****************    
    case 'DSW1'
        c(1)=c1;
        c(g1)=infsup(1,1);
        ma=max(0.45*abs(sin(0.5*pi*t)),0.5+0.45*abs(sin(0.5*pi*t)));
        mi=min(0.45*abs(sin(0.5*pi*t)),0.5+0.45*abs(sin(0.5*pi*t)));
        c(g2)=infsup(mi,ma);
        Gt=mid(infsup(mi,ma));
        f1=(c(1)*x(1)-Gt)^2  +sum(c(g1).*x(g1).^2)+sum(c(g2).*(x(g2)-Gt).^2);
        f2=(c(1)*x(1)-Gt-2)^2+sum(c(g1).*x(g1).^2)+sum(c(g2).*(x(g2)-Gt).^2);
        
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% *********************** DSW2���Ժ���*****************      
    case 'DSW2'
        c(1)=c1;
        c(g1)=infsup(1,1);
        ma=max(0.45*abs(sin(0.5*pi*t)),0.5+0.45*abs(sin(0.5*pi*t)));
        mi=min(0.45*abs(sin(0.5*pi*t)),0.5+0.45*abs(sin(0.5*pi*t)));
        c(g2)=infsup(mi,ma);
        Gt=mid(infsup(mi,ma));
        f1=(abs(c(1)*x(1))-Gt)^2+sum(c(g1).*x(g1).^2)+sum(c(g2).*(x(g2)-Gt).^2);
        f2=(abs(c(1)*x(1))-Gt-2)^2+sum(c(g1).*x(g1).^2)+sum(c(g2).*(x(g2)-Gt).^2);
        
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% *********************** DSW3���Ժ���*****************     
    case 'DSW3'
        c(1)=c1;
        c(g1)=infsup(1,1);
        ma=max(0.45*abs(sin(0.5*pi*t)),0.5+0.45*abs(sin(0.5*pi*t)));
        mi=min(0.45*abs(sin(0.5*pi*t)),0.5+0.45*abs(sin(0.5*pi*t)));
        c(g2)=infsup(mi,ma);
        Gt=mid(infsup(mi,ma));

        f1=(c(1)*x(1))^2+sum(c(g1).*x(g1).^2)+sum(c(g2).*(x(g2)-Gt).^2);
        f2=(c(1)*x(1)-Gt-2)^2+sum(c(g1).*x(g1).^2)+sum(c(g2).*(x(g2)-Gt).^2);
        
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);     
    %% DFϵ��
    %% *********************** DF1���Ժ���***************** 
    case 'DF1'  %DMOP2
        c(1)=c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);
        end
        g_xm=1+sum(c(2:nVar).*(x(2:nVar)-mid(c(2:nVar))).^2);%
        f1 = c(1)*x(1);
        Ht=1.25+0.75*(sin(0.5*pi*t));
        h = 1-(f1./g_xm)^Ht;
        f2 = g_xm * h;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% *********************** DF2���Ժ���***************** 
    case 'DF2' %DMOP3
        c(1)=c1;
        g = 1;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);    
        end
        Gt = abs(sin(pi*t/2));
        r = 1 + floor((nVar-1)*Gt);
        f1 = x(r) * c(1);
        for i = 1:nVar
            if i == r
                continue
            else
                g = g + (c(i).*(x(i)-mid(c(i))).^2);
            end
        end
        h = 1 - sqrt(f1/g);
        f2 = g * h;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
   %% *********************** DF3���Ժ���***************** 
    case 'DF3' %ZJZ
        c(1)=c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);    
        end
        Gt = sin(pi*t/2);
        Ht = 1.5 + Gt;
        g = 1 + sum(c(2:nVar).*(x(2:nVar)-mid(c(2:nVar))-x(1).^Ht).^2);
        f1 = c(1) * x(1);
        h = 1 - (f1./g).^Ht;
        f2 = g * h;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% *********************** DF4���Ժ���***************** 
    case 'DF4'
        a = sin(0.5*pi*t);
        b = 1 + abs(cos(0.5*pi*t));
        Ht = 1.5 + a;
        c(1)=c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);    
        end
        g = 1;
        for i = 2:nVar
            g = g + c(i)*((x(i)-(a*c(1)*x(1)^2)/i)^2);
        end
        f1 = g*abs(c(1)*x(1)-a)^Ht;
        f2 = g*abs(c(1)*x(1)-a-b)^Ht;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% *********************** DF7���Ժ���***************** 
    case 'DF7'
        a = 5*cos(0.5*pi*t);
        c(1)=c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);    
        end
        g =  1 + sum(c(2:nVar).*(x(2:nVar)-1/(1+exp(a*(x(1)-2.5)))).^2);
        f1 = g*(1+t)/(c(1)*x(1));
        f2 = g*(c(1)*x(1))/(1+t);
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
   %% *********************** DF9���Ժ���***************** 
    case 'DF9'
        N = 1 + floor(10*abs(sin(0.5*pi*t))); %�ֿ���
        c(1)=c1;
        summ = 0;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);    
            summ = summ + c(i)*(x(i)-cos(4*t+x(1)+x(i-1)))^2;
        end
        g = 1 + summ;
        f1 = g*(c(1)*x(1) + max(0,(0.1+0.5/N)*sin(2*N*pi*x(1))));
        f2 = g*(1 - c(1)*x(1) + max(0,(0.1+0.5/N)*sin(2*N*pi*x(1))));
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
   %% *********************** DF11���Ժ���***************** 
    case 'DF11'
        c(1)=c1;
        c(g1)=infsup(1,1);
        for i=1:numel(g2)
            j=g2(i);
            ma=max(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            mi=min(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            c(j)=infsup(mi,ma);
        end
        Gt = abs(sin(0.5*pi*t));
        y(1:2) = pi*Gt/6+(pi/2-pi*Gt/3).*x(1:2);
        g = 1 + Gt + sum(c(3:nVar).*(x(3:nVar)-0.5*Gt*c(1)*x(1)).^2);
        f1 = g*sin(c(1)*y(1));
        f2 = g*sin(c(2)*y(2))*cos(c(1)*y(1));
        f3 = g*cos(c(2)*y(2))*cos(c(1)*y(1));
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
        f(5)=inf(f3);
        f(6)=sup(f3);
    %% *********************** DF12���Ժ���***************** 
    case 'DF12'
       c(1)=c1;
        c(g1)=infsup(1,1);
        for i=1:numel(g2)
            j=g2(i);
            ma=max(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            mi=min(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            c(j)=infsup(mi,ma);
        end
        kt = 10 * sin(pi*t);
        g = 1+sum(c(3:nVar).*(x(3:nVar)-sin(t*x(1))).^2) + abs(sin(floor(kt*(2*x(1)-1))*pi/2) * sin(floor(kt*(2*x(2)-1))*pi/2));
        f1 = g.*cos(0.5*pi*x(1)*c(1)).*cos(0.5*pi*c(2)*x(2));
        f2 = g.*cos(0.5*pi*c(1)*x(1)).*sin(0.5*pi*c(2)*x(2));
        f3 = g.*sin(0.5*pi*c(1)*x(1));
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
        f(5)=inf(f3);
        f(6)=sup(f3);
    %% *********************** DIMP1���Ժ���***************** 
    case 'DIMP1'
        c(1)=c1;
        summ = 0;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);    
            summ = c(i)*(x(i)-sin(0.5*pi*t + 2*pi*(i/(nVar+1))).^2).^2;
        end
        g = 1 + summ;
        f1 = c1*x(1);
        h = 1 - (f1./g).^2;
        f2 = g*h;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% *********************** DIMP2���Ժ���***************** 
    case 'DIMP2'
        c(1)=c1;
        summ = 0;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);   
            Gt = sin(0.5*pi*t + 2*pi*(i/(nVar+1))).^2;
            summ = c(i) * ((x(i)-Gt)^2 - 2*cos(3*pi*(x(i)-Gt)));  
        end
        g = 1 + 2*(nVar - 1) + summ;
        f1 = c1*x(1);
        h = 1 - sqrt(f1./g);
        f2 = g*h;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% ��Ŀ����Ժ���
    %% *********************** FDA4.3���Ժ���***************** 
    case {'FDA4.1'}
        c(1)=c1;
        c(g1)=infsup(1,1);
        for i=1:numel(g2)
            j=g2(i);
            ma=max(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            mi=min(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            c(j)=infsup(mi,ma);
        end
%         g11=sum(c(g1).*(x(g1)-0.5).^2);
        g22=sum(c(g2).*(x(g2)-mid(c(g2))).^2);
        g_xm=g22;
        f1 = (1+g_xm)*cos(0.5*pi*c(1)*x(1))*cos(0.5*pi*c(2).*x(2));
        f2 = (1+g_xm)*cos(0.5*pi*c(1)*x(1))*sin(0.5*pi*c(2).*x(2));
        f3 = (1+g_xm)*sin(0.5*pi*c(1)*x(1));
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
        f(5)=inf(f3);
        f(6)=sup(f3);
   %% *********************** FDA5.3���Ժ���***************** 
    case 'FDA5.1'
        c(1)=c1;
        c(g1)=infsup(1,1);
        for i=1:numel(g2)
            j=g2(i);
            ma=max(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            mi=min(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            c(j)=infsup(mi,ma);
        end
        Gt = abs(sin(0.5*pi*t));
        g22=Gt+sum(c(g2).*(x(g2)-mid(c(g2))).^2);
        Ft = 1 + 100*(sin(0.5*pi*t))^4;
        y(1:2) = x(1:2).^Ft;
        f1 = (1+g22)*cos(c(1)*y(1)*pi*0.5).*cos(0.5*pi*c(2)*y(2));
        f2 = (1+g22)*cos(c(1)*y(1)*pi*0.5).*sin(0.5*pi*c(2)*y(2));
        f3 = (1+g22)*sin(c(1)*y(1)*pi*0.5);
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
        f(5)=inf(f3);
        f(6)=sup(f3);
   %% *********************** SJY1���Ժ���***************** 
    case 'SJY1'
       c(1)=c1;
       c(g1)=infsup(1,1);
       for i=1:numel(g2)
            j=g2(i);
            ma=max(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            mi=min(0.45*abs(sin(0.5*j*pi*t)),0.5+0.45*abs(sin(0.5*j*pi*t)));
            c(j)=infsup(mi,ma);
        end
        Gt = sin(0.5*pi*t);
        s = sum(c(4:nVar).*(x(4:nVar)-Gt).^2);
        f1 = (1+s)*(c(1)*x(1)/sum(x(1:3)));
        f2 = (1+s)*(c(2)*x(2)/sum(x(1:3)));
        f3 = (1+s)*(c(3)*x(3)/sum(x(1:3)));
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
        f(5)=inf(f3);
        f(6)=sup(f3);
    %% HEϵ��
    %% *********************** HE1���Ժ���***************** 
    case {'HE1'}
        c(1)=c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);    
        end
        f1 = c1.*x(1);
        g = 1 + 9*sum(c(2:nVar).*(x(2:nVar)-mid(c(2:end))).^2)./(nVar-1);
        h = 1 - sqrt(f1./g)-(f1./g).*sin(10*pi*f1);
        f2 = g.*h;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
   %% *********************** HE2���Ժ���***************** 
   case {'HE2'}
        c(1)=c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);    
        end
        H = 0.75*sin(0.5*pi*t)+1.25;
        f1 = c1.*x(1);
        g = 1 + 9*sum(c(2:nVar).*(x(2:nVar)-mid(c(2:nVar))).^2)./(nVar-1);
        h = 1 - (sqrt(f1./g)).^H-(f1./g).^H.*sin(10*pi*f1);
        f2 = g.*h;
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% UDFϵ��
    %% *********************** UDF2���Ժ���***************** 
    case {'UDF2'}
        c(1) = c1;
        N = nVar;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);    
        end
        G = sin(0.5*pi*t);
        J1 = (3:2:N);J2 = (2:2:N);
        Y(2:N) = x(2:N)-x(1).^(0.5*(2+3*((2:N)-2)/(N-2)+G))-G;
        f1 = c1*x(1)+abs(G)+2/length(J1)*sum(c(J1).*Y(J1).^2);
        f2 = 1-c1*x(1)+abs(G)+2/length(J2)*sum(c(J2).*Y(J2).^2);
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% *********************** UDF5���Ժ���***************** 
    case {'UDF5'}
        c(1) = c1;
        for i=2:nVar
            ma=max(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            mi=min(0.45*abs(sin(0.5*i*pi*t)),0.5+0.45*abs(sin(0.5*i*pi*t)));
            c(i)=infsup(mi,ma);    
        end
        G = sin(0.5*pi*t);
        H = 0.5+abs(G);
        N = nVar;
        J1 = (3:2:N);J2 = (2:2:N);
        Y(2:N) = x(2:N)-x(1).^(0.5*(2+3*((2:N)-2)/(N-2)+ G))-G;
        f1 = c1*x(1)+2/length(J1)*sum(c(J1).*Y(J1).^2);
        f2 = 1-H*c1*x(1)^H+2/length(J2)*sum(c(J2).*Y(J2).^2);
        f(1)=inf(f1);
        f(2)=sup(f1);
        f(3)=inf(f2);
        f(4)=sup(f2);
    %% Check for error
    if length(f) ~= nObj
       error('The number of decision variables does not match you previous input. Kindly check your objective function');
    end
end

