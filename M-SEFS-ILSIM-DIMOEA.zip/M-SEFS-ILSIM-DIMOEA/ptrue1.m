function fit=ptrue1(name,t,g1,g2)
c1=infsup(0.9,1);                                                          %c1ΪĿ�꺯����x1��Ӧ���������ȡֵ,��evaluate_objective�еı���һ�¡�
N = 1000;  %���޸�
M = 3;
switch name
    case {'DF11','DF12'}
         R = UniformPoint(N,M);
         fit = R./repmat(sqrt(sum(R.^2,2)),1,M);
    case {'FDA4.1'}
         R = UniformPoint(N,M);
         fit = R./repmat(sqrt(sum(R.^2,2)),1,M);
    case {'FDA5.1'}
        a = linspace(0,pi/2,100)';
        Gt = abs(sin(0.5*pi*t));
        R = 1 + Gt;
        f1 = R*sin(a)*cos(a');
        f2 = R*sin(a)*sin(a');
        f3 = R*cos(a)*ones(size(a'));
        fit(:,1) = f1(:);
        fit(:,2) = f2(:);
        fit(:,3) = f3(:);
    case 'SJY1'
        fit = UniformPoint(N,M);
end
end

