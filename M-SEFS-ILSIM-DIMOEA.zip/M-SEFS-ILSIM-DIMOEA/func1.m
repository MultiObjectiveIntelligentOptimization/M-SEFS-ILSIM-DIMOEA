function result = func1(name,x,nObj,nVar,t,g1,g2,new_f)
% result =[];
f = evaluate_objective(name, x, nObj, nVar, t, g1, g2);
summ = 0;
for i = 1:nObj/2
    d = max(abs(f(2*i-1)-new_f(2*i-1)),abs(f(2*i)-new_f(2*i)));
    summ = summ + d^2;
end
result = summ;

end

